package com.migrate.service;

import org.springframework.stereotype.Service;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class UploadProgressService {
    // Key = unique file/session identifier, Value = progress in %
    private final ConcurrentHashMap<String, AtomicInteger> progressMap = new ConcurrentHashMap<>();

    public void init(String key) {
        progressMap.put(key, new AtomicInteger(0));
    }

    public void setProgress(String key, int progress) {
        progressMap.get(key).set(progress);
    }

    public int getProgress(String key) {
        return progressMap.getOrDefault(key, new AtomicInteger(0)).get();
    }

    public void remove(String key) {
        progressMap.remove(key);
    }
}

