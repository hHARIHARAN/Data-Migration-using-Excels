package com.migrate.service;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UploadListService {

    private final JdbcTemplate jdbcTemplate;

    public UploadListService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<String> getUploadedTables() {
        String sql = "SELECT table_name " +
                     "FROM information_schema.tables " +
                     "WHERE table_schema = DATABASE() " +
                     "ORDER BY create_time DESC";  // newest tables first
        return jdbcTemplate.queryForList(sql, String.class);
    }
}

