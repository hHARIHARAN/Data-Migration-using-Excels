package com.migrate.service;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFReader.SheetIterator;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.io.InputStream;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class ExcelService {

    private final UploadProgressService uploadProgressService;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    final List<SimpleDateFormat> DATE_FORMATS = Arrays.asList(
            new SimpleDateFormat("yyyy-MM-dd"),
            new SimpleDateFormat("dd-MM-yyyy"),
            new SimpleDateFormat("dd/MM/yyyy"),
            new SimpleDateFormat("MM/dd/yyyy")
    );

    private final int BATCH_SIZE = 1000;
    private final int TYPE_SAMPLE_ROWS = 100;
    
    
    
    ExcelService(UploadProgressService uploadProgressService) {
        this.uploadProgressService = uploadProgressService;
    }

    public void processLargeExcel(MultipartFile file) throws Exception {

        String originalName = Objects.requireNonNull(file.getOriginalFilename());
        String tableName = sanitizeName(originalName.replace(".xlsx",""));

        if (tableExists(tableName)) {
            throw new RuntimeException("This Excel has already been uploaded: " + originalName);
        }

        // ------------------- First pass: detect column types -------------------
        List<String> columns = new ArrayList<>();
        List<List<String>> sampleDataPerColumn = new ArrayList<>();

        try (OPCPackage pkg = OPCPackage.open(file.getInputStream())) {
            XSSFReader reader = new XSSFReader(pkg);
            SharedStringsTable sst = (SharedStringsTable) reader.getSharedStringsTable();
            XSSFReader.SheetIterator sheets = (SheetIterator) reader.getSheetsData();

            if (!sheets.hasNext()) throw new RuntimeException("Excel has no sheets");

            InputStream sheetInputStream = sheets.next();
            InputSource sheetSource = new InputSource(sheetInputStream);

            AtomicInteger rowCount = new AtomicInteger(0);

            XSSFSheetXMLHandler.SheetContentsHandler headerHandler = new XSSFSheetXMLHandler.SheetContentsHandler() {
                private int currentRow = -1;
                private Map<Integer,String> rowMap = new HashMap<>();

                @Override
                public void startRow(int rowNum) { currentRow = rowNum; rowMap.clear(); }

                @Override
                public void endRow(int rowNum) {
                    if (currentRow == 0) {
                        Set<String> colSet = new HashSet<>();
                        for (int i = 0; i < rowMap.size(); i++) {
                            String colName = sanitizeName(rowMap.get(i));
                            if (!colSet.add(colName)) throw new RuntimeException("Duplicate column: " + colName);
                            columns.add(colName);
                            sampleDataPerColumn.add(new ArrayList<>());
                        }
                    } else if (rowCount.get() < TYPE_SAMPLE_ROWS) {
                        for (int i = 0; i < columns.size(); i++) {
                            sampleDataPerColumn.get(i).add(rowMap.getOrDefault(i,""));
                        }
                        rowCount.incrementAndGet();
                    }
                }

                @Override
                public void cell(String cellReference, String formattedValue, XSSFComment comment) {
                    int colIndex = getColumnIndex(cellReference);
                    rowMap.put(colIndex, formattedValue);
                }

                @Override
                public void headerFooter(String text, boolean isHeader, String tagName) { }
            };

            XMLReader parser = XMLReaderFactory.createXMLReader();
            parser.setContentHandler(new XSSFSheetXMLHandler(null, null, sst, headerHandler, new DataFormatter(), false));
            parser.parse(sheetSource);
        }

        List<String> columnTypes = new ArrayList<>();
        for (List<String> colData : sampleDataPerColumn) {
            columnTypes.add(detectColumnType(colData));
        }

        createTable(tableName, columns, columnTypes);

        // ------------------- Second pass: insert all rows -------------------
        try (OPCPackage pkg = OPCPackage.open(file.getInputStream())) {
            XSSFReader reader = new XSSFReader(pkg);
            SharedStringsTable sst = (SharedStringsTable) reader.getSharedStringsTable();
            XSSFReader.SheetIterator sheets = (SheetIterator) reader.getSheetsData();
            InputStream sheetInputStream = sheets.next();
            InputSource sheetSource = new InputSource(sheetInputStream);

            List<Map<String,Object>> batchData = new ArrayList<>();

            XSSFSheetXMLHandler.SheetContentsHandler insertHandler = new XSSFSheetXMLHandler.SheetContentsHandler() {
                private int currentRow = -1;
                private Map<Integer,String> rowMap = new HashMap<>();

                @Override
                public void startRow(int rowNum) { currentRow = rowNum; rowMap.clear(); }

                @Override
                public void endRow(int rowNum) {
                    if (currentRow == 0) return;

                    Map<String,Object> rowData = new LinkedHashMap<>();
                    for (int i = 0; i < columns.size(); i++) {
                        String val = rowMap.getOrDefault(i,"");
                        String type = columnTypes.get(i);
                        rowData.put(columns.get(i), convertValue(val, type));
                    }
                    batchData.add(rowData);

                    if (batchData.size() >= BATCH_SIZE) {
                        insertBatch(tableName, columns, batchData);
                        batchData.clear();
                    }
                }

                @Override
                public void cell(String cellReference, String formattedValue, XSSFComment comment) {
                    int colIndex = getColumnIndex(cellReference);
                    rowMap.put(colIndex, formattedValue);
                }

                @Override
                public void headerFooter(String text, boolean isHeader, String tagName) { }
            };

            XMLReader parser = XMLReaderFactory.createXMLReader();
            parser.setContentHandler(new XSSFSheetXMLHandler(null, null, sst, insertHandler, new DataFormatter(), false));
            parser.parse(sheetSource);

            if (!batchData.isEmpty()) insertBatch(tableName, columns, batchData);
        }
    }

    private int getColumnIndex(String cellRef) {
        String col = cellRef.replaceAll("\\d","");
        int index = 0;
        for (char c : col.toCharArray()) index = index * 26 + (c - 'A' + 1);
        return index - 1;
    }

    private String sanitizeName(String name) {
        name = name.toLowerCase().replaceAll("[^a-z0-9_]","_");
        if (name.matches("^[0-9].*")) name = "col_" + name;
        return name;
    }

    private boolean tableExists(String tableName) {
        String sql = "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?";
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class, tableName);
        return count != null && count > 0;
    }

    private void createTable(String tableName, List<String> columns, List<String> columnTypes) {
        StringBuilder sb = new StringBuilder("CREATE TABLE `").append(tableName).append("` (");
        for (int i = 0; i < columns.size(); i++) {
            sb.append("`").append(columns.get(i)).append("` ").append(columnTypes.get(i)).append(",");
        }
        sb.setLength(sb.length()-1);
        sb.append(")");
        jdbcTemplate.execute(sb.toString());
    }

    private void insertBatch(String tableName, List<String> columns, List<Map<String,Object>> batchData) {
        if (batchData.isEmpty()) return;

        StringBuilder sql = new StringBuilder("INSERT INTO `").append(tableName).append("` (");
        for (String col : columns) sql.append("`").append(col).append("`,");
        sql.setLength(sql.length()-1);
        sql.append(") VALUES ");

        List<Object> params = new ArrayList<>();
        for (Map<String,Object> row : batchData) {
            sql.append("(");
            for (String col : columns) {
                sql.append("?,");
                params.add(row.get(col));
            }
            sql.setLength(sql.length()-1);
            sql.append("),");
        }
        sql.setLength(sql.length()-1);
        jdbcTemplate.update(sql.toString(), params.toArray());
    }

    private String detectColumnType(List<String> values) {
        boolean isInt = true;
        boolean isDouble = true;
        boolean isDate = true;

        for (String val : values) {
            if (val == null || val.trim().isEmpty()) continue;
            val = val.trim();

            // 1️⃣ Check string date first
            if (isDate && isValidDate(val)) continue;

            // 2️⃣ Check numeric
            double numericVal = 0;
            boolean isNumeric = false;
            try {
                numericVal = Double.parseDouble(val);
                isNumeric = true;
            } catch (NumberFormatException ignored) {}

            if (isNumeric) {
                // Integer check
                if (isInt && numericVal % 1 != 0) isInt = false;

                // Date check for numeric Excel date
                // Only treat numeric > 59 (Excel leap year bug) as date if isDate still true
                if (isDate) {
                    if (numericVal <= 59 || numericVal > 60000) { 
                        isDate = false;
                    }
                }
            } else {
                // Not numeric and not a valid date string → cannot be number or date
                isInt = false;
                isDouble = false;
                if (!isValidDate(val)) isDate = false;
            }

            if (!isInt && !isDouble && !isDate) break;
        }

        if (isDate) return "DATE";
        if (isInt) return "BIGINT";
        if (isDouble) return "DOUBLE";
        return "VARCHAR(255)";
    }

    private Object convertValue(String val, String type) {
        if (val == null || val.trim().isEmpty()) return null;
        val = val.trim();

        try {
            switch (type) {
                case "BIGINT":
                    return Long.parseLong(val);
                case "DOUBLE":
                    return Double.parseDouble(val);
                case "DATE":
                    // 1️⃣ Try numeric Excel date first
                    try {
                        double numericVal = Double.parseDouble(val);
                        if (numericVal > 59 && numericVal < 60000) {
                            return new java.sql.Date(DateUtil.getJavaDate(numericVal).getTime());
                        }
                    } catch (NumberFormatException ignored) {}
                    // 2️⃣ Fallback to string date parsing
                    return parseToSqlDate(val);
                default:
                    return val;
            }
        } catch (Exception e) {
            return val; // fallback to string
        }
    }



    private boolean isValidDate(String val) {
        List<SimpleDateFormat> DATE_FORMATS = Arrays.asList(
            new SimpleDateFormat("yyyy-MM-dd"),
            new SimpleDateFormat("dd-MM-yyyy"),
            new SimpleDateFormat("dd/MM/yyyy"),
            new SimpleDateFormat("MM/dd/yyyy")
        );
        for (SimpleDateFormat fmt : DATE_FORMATS) {
            try {
                fmt.setLenient(false);
                fmt.parse(val);
                return true;
            } catch (Exception ignored) {}
        }
        return false;
    }

    private java.sql.Date parseToSqlDate(String val) {
        List<SimpleDateFormat> DATE_FORMATS = Arrays.asList(
            new SimpleDateFormat("yyyy-MM-dd"),
            new SimpleDateFormat("dd-MM-yyyy"),
            new SimpleDateFormat("dd/MM/yyyy"),
            new SimpleDateFormat("MM/dd/yyyy")
        );
        for (SimpleDateFormat fmt : DATE_FORMATS) {
            try {
                fmt.setLenient(false);
                java.util.Date parsed = fmt.parse(val);
                return new java.sql.Date(parsed.getTime());
            } catch (Exception ignored) {}
        }
        return null;
    }
    
    public List<String> getUploadedTables() {
        try {
            // Get current database name
            String dbName = jdbcTemplate.queryForObject("SELECT DATABASE()", String.class);
            if (dbName == null) dbName = "";

            // Query table names
            String sql = "SELECT table_name " +
                         "FROM information_schema.tables " +
                         "WHERE table_schema = ? " +
                         "ORDER BY table_name ASC"; // safe ordering
            List<String> tables = jdbcTemplate.queryForList(sql, String.class, dbName);

            // Return empty list if null
            if (tables == null) return new ArrayList<>();
            return tables;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

}










