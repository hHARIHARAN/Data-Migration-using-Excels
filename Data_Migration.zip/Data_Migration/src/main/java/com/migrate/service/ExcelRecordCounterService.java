package com.migrate.service;

import com.migrate.entity.ExcelUploadMetadata;
import com.migrate.repository.ExcelUploadMetadataRepository;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFComment;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class ExcelRecordCounterService {

    private final ExcelUploadMetadataRepository repository;

    public ExcelRecordCounterService(ExcelUploadMetadataRepository repository) {
        this.repository = repository;
    }

    /**
     * Count rows and create/update ExcelUploadMetadata entity
     */
    public ExcelUploadMetadata countAndSave(MultipartFile file) throws Exception {

        String fileName = file.getOriginalFilename();
        if (fileName == null) fileName = "unknown_file";

        AtomicInteger totalRows = new AtomicInteger(0);

        try (OPCPackage pkg = OPCPackage.open(file.getInputStream())) {
            XSSFReader reader = new XSSFReader(pkg);
            SharedStringsTable sst = (SharedStringsTable) reader.getSharedStringsTable();
            InputStream sheet = reader.getSheetsData().next();
            InputSource sheetSource = new InputSource(sheet);

            XSSFSheetXMLHandler.SheetContentsHandler handler =
                    new XSSFSheetXMLHandler.SheetContentsHandler() {

                private int currentRow = -1;
                private Map<Integer, String> rowMap = new HashMap<>();

                @Override
                public void startRow(int rowNum) {
                    currentRow = rowNum;
                    rowMap.clear();
                }

                @Override
                public void endRow(int rowNum) {
                    if (currentRow == 0) return; // skip header
                    totalRows.incrementAndGet();
                }

                @Override
                public void cell(String cellReference, String formattedValue, XSSFComment comment) {
                    rowMap.put(getColumnIndex(cellReference), formattedValue);
                }

                @Override
                public void headerFooter(String text, boolean isHeader, String tagName) {}
            };

            XMLReader parser = XMLReaderFactory.createXMLReader();
            parser.setContentHandler(
                new XSSFSheetXMLHandler(null, null, sst, handler, new DataFormatter(), false)
            );
            parser.parse(sheetSource);
        }

        // 🔹 Create or Update entity
        ExcelUploadMetadata metadata = repository
                .findByFileName(fileName)
                .orElse(new ExcelUploadMetadata());

        metadata.setFileName(fileName);
        metadata.setRecordCount(totalRows.get());
        metadata.setUploadedAt(java.time.LocalDateTime.now());

        return repository.save(metadata);
    }

    private int getColumnIndex(String cellRef) {
        String col = cellRef.replaceAll("\\d", "");
        int index = 0;
        for (char c : col.toCharArray()) {
            index = index * 26 + (c - 'A' + 1);
        }
        return index - 1;
    }
}


