package com.migrate.service;


import com.migrate.dto.MigrationReportRow;
import com.migrate.entity.ExcelUploadMetadata;
import com.migrate.repository.ExcelUploadMetadataRepository;
import com.lowagie.text.*;
import com.lowagie.text.pdf.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.awt.Color;

@Service
public class MigrationReportService {

    private final ExcelUploadMetadataRepository metadataRepo;
    private final JdbcTemplate jdbcTemplate;

    public MigrationReportService(ExcelUploadMetadataRepository metadataRepo,
                                  JdbcTemplate jdbcTemplate) {
        this.metadataRepo = metadataRepo;
        this.jdbcTemplate = jdbcTemplate;
    }
    
    @Value("${migration.source}")
    private String source;

    @Value("${migration.destination}")
    private String destination;

    @Value("${migration.database.name}")
    private String databaseName;

    public byte[] generatePdfReport() throws Exception {

        List<ExcelUploadMetadata> metadataList =
                metadataRepo.findAllByOrderByFileNameAsc();

        List<MigrationReportRow> reportRows = new ArrayList<>();

        for (ExcelUploadMetadata meta : metadataList) {

            String tableName =
                    meta.getFileName().replace(".xlsx", "").toLowerCase();

            Integer dbCount = jdbcTemplate.queryForObject(
                    "SELECT COUNT(*) FROM `" + tableName + "`",
                    Integer.class
            );

            reportRows.add(
                new MigrationReportRow(
                    meta.getFileName(),
                    tableName,
                    meta.getRecordCount(),
                    dbCount != null ? dbCount : 0
                )
            );
        }

        return createPdf(reportRows);
    }

    // ================= PDF CREATION =================
    private byte[] createPdf(List<MigrationReportRow> rows) throws Exception {

        Document document = new Document(PageSize.A4);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        PdfWriter.getInstance(document, out);

        document.open();

        // ================= FONTS =================
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
        Font labelFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
        Font valueFont = FontFactory.getFont(FontFactory.HELVETICA, 10);
        Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
        Font bodyFont = FontFactory.getFont(FontFactory.HELVETICA, 10);

        // ================= TITLE (CENTER) =================
        Paragraph title = new Paragraph(
                "JiVS Data Migration Completeness Report", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);

        document.add(Chunk.NEWLINE);

        // ================= LEFT SIDE METADATA =================
        PdfPTable infoTable = new PdfPTable(2);
        infoTable.setWidthPercentage(60);
        infoTable.setHorizontalAlignment(Element.ALIGN_LEFT);
        infoTable.setSpacingAfter(15f);

        addInfoRow(infoTable, "Database Name", databaseName, labelFont, valueFont);
        addInfoRow(infoTable, "Source Files", source, labelFont, valueFont);
        addInfoRow(infoTable, "Destination", destination, labelFont, valueFont);
        addInfoRow(infoTable, "Report Date", LocalDate.now().toString(), labelFont, valueFont);

        document.add(infoTable);

        // ================= MAIN TABLE =================
        PdfPTable table = new PdfPTable(5);
        table.setWidthPercentage(100);
        table.setWidths(new float[]{3, 2, 3, 2, 2});

        // ---------- TOP HEADER ROW ----------
        PdfPCell sourceHeader = new PdfPCell(new Phrase("SOURCE", headerFont));
        sourceHeader.setColspan(2);
        sourceHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        sourceHeader.setBackgroundColor(Color.LIGHT_GRAY);
        table.addCell(sourceHeader);

        PdfPCell destHeader = new PdfPCell(new Phrase("DESTINATION", headerFont));
        destHeader.setColspan(2);
        destHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        destHeader.setBackgroundColor(Color.LIGHT_GRAY);
        table.addCell(destHeader);

        PdfPCell statusHeader = new PdfPCell(new Phrase("STATUS", headerFont));
        statusHeader.setRowspan(2);
        statusHeader.setHorizontalAlignment(Element.ALIGN_CENTER);
        statusHeader.setVerticalAlignment(Element.ALIGN_MIDDLE);
        statusHeader.setBackgroundColor(Color.LIGHT_GRAY);
        table.addCell(statusHeader);

        // ---------- SECOND HEADER ROW ----------
        addHeader(table, headerFont, "Excel Name");
        addHeader(table, headerFont, "Row Count");
        addHeader(table, headerFont, "Table Name");
        addHeader(table, headerFont, "Row Count");

        // ---------- DATA ROWS ----------
        for (MigrationReportRow row : rows) {

            table.addCell(new Phrase(row.getExcelName(), bodyFont));
            table.addCell(new Phrase(String.valueOf(row.getExcelCount()), bodyFont));
            table.addCell(new Phrase(row.getTableName(), bodyFont));
            table.addCell(new Phrase(String.valueOf(row.getDbCount()), bodyFont));

            Font statusFont = row.getStatus().equals("MATCHED")
                    ? FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.GREEN)
                    : FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.RED);

            PdfPCell statusCell = new PdfPCell(new Phrase(row.getStatus(), statusFont));
            statusCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(statusCell);
        }

        document.add(table);
        document.close();

        return out.toByteArray();
    }
    

    private void addHeader(PdfPTable table, Font font, String text) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setBackgroundColor(Color.LIGHT_GRAY);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(cell);
    }

    private void addInfoRow(PdfPTable table, String label, String value,
                            Font labelFont, Font valueFont) {

        PdfPCell labelCell = new PdfPCell(new Phrase(label + " :", labelFont));
        labelCell.setBorder(Rectangle.NO_BORDER);

        PdfPCell valueCell = new PdfPCell(new Phrase(value, valueFont));
        valueCell.setBorder(Rectangle.NO_BORDER);

        table.addCell(labelCell);
        table.addCell(valueCell);
    }

}

