package com.migrate.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "excel_upload_metadata")
public class ExcelUploadMetadata {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_name", nullable = false)
    private String fileName;

    @Column(name = "record_count", nullable = false)
    private Integer recordCount;

    @Column(name = "uploaded_at")
    private LocalDateTime uploadedAt;

    // Constructors
    public ExcelUploadMetadata() {}

    public ExcelUploadMetadata(String fileName, Integer recordCount) {
        this.fileName = fileName;
        this.recordCount = recordCount;
        this.uploadedAt = LocalDateTime.now();
    }

    // Getters & Setters
    public Long getId() { return id; }

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public Integer getRecordCount() { return recordCount; }
    public void setRecordCount(Integer recordCount) { this.recordCount = recordCount; }

    public LocalDateTime getUploadedAt() { return uploadedAt; }
    public void setUploadedAt(LocalDateTime uploadedAt) { this.uploadedAt = uploadedAt; }
}

