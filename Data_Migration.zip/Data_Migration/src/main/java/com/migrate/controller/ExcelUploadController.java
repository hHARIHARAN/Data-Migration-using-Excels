package com.migrate.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.migrate.entity.ExcelUploadMetadata;
import com.migrate.exception.ExcelValidationException;
import com.migrate.repository.ExcelUploadMetadataRepository;
import com.migrate.service.ExcelRecordCounterService;
import com.migrate.service.ExcelService;
import com.migrate.service.MigrationReportService;

@Controller
public class ExcelUploadController {

    private final ExcelService excelService;
    
    @Autowired
    private ExcelRecordCounterService excelRecordCounterService;
    
    @Autowired
    private ExcelUploadMetadataRepository excelUploadMetadataRepository;
    
    @Autowired
    private MigrationReportService migrationReportService;

    public ExcelUploadController(ExcelService excelService) {
        this.excelService = excelService;
    }

    @GetMapping("/")
    public String uploadPage(Model model) {
    	model.addAttribute("uploadedTables", excelService.getUploadedTables());
    	
    	// 🔹 NEW: fetch metadata
        List<ExcelUploadMetadata> uploads =
                excelUploadMetadataRepository.findAllByOrderByFileNameAsc();

        model.addAttribute("uploadMetadata", uploads);
        return "upload";
    }

    @PostMapping("/upload")
    public String uploadExcel(@RequestParam("file") MultipartFile file,
                              Model model) {

        try {
            excelService.processLargeExcel(file);
            model.addAttribute("success",
                    "Excel uploaded successfully: " + file.getOriginalFilename());
//            int recordCount = excelRecordCounterService.countAndStoreRecords(file);
//            model.addAttribute("recordCount", recordCount);
            List<ExcelUploadMetadata> uploads =
                    excelUploadMetadataRepository.findAllByOrderByFileNameAsc();

            model.addAttribute("uploadMetadata", uploads);
            ExcelUploadMetadata meta =
                    excelRecordCounterService.countAndSave(file);
            model.addAttribute("recordCount", meta.getRecordCount());
        } catch (ExcelValidationException ex) {
            // ✅ SHOW EXACT MESSAGE
            model.addAttribute("error", ex.getMessage());
        } catch (Exception ex) {
            // generic error
            model.addAttribute("error", "Failed to process Excel file: " + ex.getMessage());
            model.addAttribute("recordCount", 0);
        }
        model.addAttribute("uploadedTables", excelService.getUploadedTables());
        return "upload"; // same page
    }
    
    @GetMapping("/migration-report")
    public ResponseEntity<byte[]> downloadReport() {
        try {
            byte[] pdf = migrationReportService.generatePdfReport();

            return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=migration-report.pdf")
                .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                .body(pdf);

        } catch (Exception e) {
            return ResponseEntity.internalServerError().build();
        }
    }

}



