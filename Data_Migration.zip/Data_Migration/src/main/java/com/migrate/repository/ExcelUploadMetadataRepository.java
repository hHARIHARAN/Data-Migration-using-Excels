package com.migrate.repository;

import com.migrate.entity.ExcelUploadMetadata;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ExcelUploadMetadataRepository
        extends JpaRepository<ExcelUploadMetadata, Long> {

    Optional<ExcelUploadMetadata> findByFileName(String fileName);
    
    List<ExcelUploadMetadata> findAllByOrderByFileNameAsc();

}
