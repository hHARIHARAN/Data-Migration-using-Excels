package com.migrate.exception;

public class ExcelValidationException extends RuntimeException {
    public ExcelValidationException(String message) {
        super(message);
    }
}

