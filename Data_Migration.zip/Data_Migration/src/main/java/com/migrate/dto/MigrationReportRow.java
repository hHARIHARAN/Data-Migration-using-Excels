package com.migrate.dto;

public class MigrationReportRow {

    private String excelName;
    private String tableName;
    private int excelCount;
    private int dbCount;
    private String status;

    // constructor
    public MigrationReportRow(String excelName, String tableName,
                              int excelCount, int dbCount) {
        this.excelName = excelName;
        this.tableName = tableName;
        this.excelCount = excelCount;
        this.dbCount = dbCount;
        this.status = excelCount == dbCount ? "MATCHED" : "MISMATCH";
    }

    // getters
    public String getExcelName() { return excelName; }
    public String getTableName() { return tableName; }
    public int getExcelCount() { return excelCount; }
    public int getDbCount() { return dbCount; }
    public String getStatus() { return status; }
}

